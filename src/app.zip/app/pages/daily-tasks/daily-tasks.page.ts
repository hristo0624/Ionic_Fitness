import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-daily-tasks',
  templateUrl: './daily-tasks.page.html',
  styleUrls: ['./daily-tasks.page.scss'],
})
export class DailyTasksPage implements OnInit {

  constructor() {
  }

  ngOnInit() {
  }

}
