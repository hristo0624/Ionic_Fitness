import { QuestionAnswerPipe } from './question-answer.pipe';

describe('QuestionAnswerPipe', () => {
  it('create an instance', () => {
    const pipe = new QuestionAnswerPipe();
    expect(pipe).toBeTruthy();
  });
});
