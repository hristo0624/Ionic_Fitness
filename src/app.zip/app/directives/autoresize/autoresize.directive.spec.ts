// import { AutoresizeDirective } from './autoresize.directive';

// describe('AutoresizeDirective', () => {
//   it('should create an instance', () => {
//     const directive = new AutoresizeDirective();
//     expect(directive).toBeTruthy();
//   });
// });
